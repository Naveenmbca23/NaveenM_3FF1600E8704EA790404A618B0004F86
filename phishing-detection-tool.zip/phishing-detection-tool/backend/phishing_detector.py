def is_phishing(input_value):
    """
    Phishing detection logic. Customize with your actual algorithm.
    """
    phishing_keywords = ['malicious', 'phish', 'scam', 'hack', 'danger', 'attack']

    # Basic detection by checking for keywords
    if any(keyword in input_value.lower() for keyword in phishing_keywords):
        return "Phishing detected!"
    
    # Check if input resembles a suspicious URL
    if input_value.startswith("http://") or input_value.startswith("https://"):
        if "@" in input_value or len(input_value.split('.')) < 2:
            return "Suspicious URL detected! May be phishing."
    
    return "Input appears safe."
