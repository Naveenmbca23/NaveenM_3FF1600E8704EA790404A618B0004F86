import mysql.connector

def create_database():
    conn = mysql.connector.connect(host='localhost', user='root', password='your_password')
    cursor = conn.cursor()
    cursor.execute('CREATE DATABASE IF NOT EXISTS phishing_detection')
    conn.commit()
    conn.close()

def create_table():
    conn = mysql.connector.connect(host='localhost', user='root', password='your_password', database='phishing_detection')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS logs (
            id INT AUTO_INCREMENT PRIMARY KEY,
            url VARCHAR(255),
            result VARCHAR(50),
            timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    conn.commit()
    conn.close()

if __name__ == '__main__':
    create_database()
    create_table()
