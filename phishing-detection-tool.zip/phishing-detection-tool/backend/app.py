from flask import Flask, request, jsonify, send_from_directory
import joblib
import mysql.connector
import re
from sklearn.feature_extraction.text import CountVectorizer
import os

app = Flask(__name__, static_folder='../frontend', static_url_path='/')

# Load the trained model and vectorizer
model = joblib.load('/media/ricky/Ricky/projects/Nuetrex/projects/phishing-detection-tool/backend/phishing_model.pkl')
vectorizer = joblib.load('/media/ricky/Ricky/projects/Nuetrex/projects/phishing-detection-tool/backend/vectorizer.pkl')

# MySQL Database connection
def log_detection(url, result):
    conn = mysql.connector.connect(
        host='localhost', user='root', password='', database='phishing_detection'
    )
    cursor = conn.cursor()
    cursor.execute("INSERT INTO logs (url, result) VALUES (%s, %s)", (url, result))
    conn.commit()
    conn.close()

def preprocess_url(url):
    url = re.sub(r'http[s]?://', '', url)
    url = re.sub(r'www\.', '', url)
    return url

# Serve the main HTML file
@app.route('/')
def serve_index():
    return send_from_directory(app.static_folder, 'index.html')

@app.route('/check-phishing', methods=['POST'])
def check_phishing():
    try:
        data = request.get_json()
        print("Received data:", data)
        url = data['url']
        preprocessed_url = preprocess_url(url)
        print("Preprocessed URL:", preprocessed_url)
        features = vectorizer.transform([preprocessed_url])
        print("Features:", features)
        prediction = model.predict(features)
        print("Prediction:", prediction)

        result = 'Phishing Detected!' if prediction[0] == 1 else 'This is a Safe URL.'
        log_detection(url, result)
        return jsonify({'message': result})
    except Exception as e:
        print("Error in /check-phishing:", e)
        return jsonify({'message': 'Error detecting phishing.'}), 500


if __name__ == '__main__':
    app.run(debug=True)
