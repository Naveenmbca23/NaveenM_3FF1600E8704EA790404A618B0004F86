document.getElementById('phishing-form').addEventListener('submit', function (e) {
    e.preventDefault();

    const url = document.getElementById('url-input').value;
    fetch('/check-phishing', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ url: url })
    })
    .then(response => response.json())
    .then(data => {
        document.getElementById('result').innerHTML = data.message;
    })
    .catch(error => {
        document.getElementById('result').innerHTML = 'Error detecting phishing.';
    });
});
document.addEventListener("DOMContentLoaded", function () {
    fetchHistory();
});

function fetchHistory() {
    fetch('/get-history')
        .then(response => response.json())
        .then(data => {
            let historyDiv = document.getElementById('history');
            historyDiv.innerHTML = "<h2>Detection History</h2>";
            data.forEach(item => {
                historyDiv.innerHTML += `<p><strong>${item.timestamp}</strong>: ${item.url} - ${item.result}</p>`;
            });
        })
        .catch(error => console.error("Error fetching history:", error));
}
