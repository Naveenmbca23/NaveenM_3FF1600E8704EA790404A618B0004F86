from flask import Flask, request, jsonify, send_from_directory
import joblib
import mysql.connector
import re
import os
import requests
from sklearn.feature_extraction.text import CountVectorizer

app = Flask(__name__, static_folder='../frontend', static_url_path='/')

# Load the trained model and vectorizer
model = joblib.load('C:\\Users\\User\\Downloads\\phishing-detection-tool\\phishing-detection-tool\\backend\\phishing_model.pkl')
vectorizer = joblib.load('C:\\Users\\User\\Downloads\\phishing-detection-tool\\phishing-detection-tool\\backend\\vectorizer.pkl')

# Telegram Bot Configuration (Replace with your credentials)
TELEGRAM_BOT_TOKEN = "7800008895:AAHSPBrInsJi0ohC4VeECwXNjlIP0bZifGo"
TELEGRAM_CHAT_ID = "5831762199"

def send_telegram_alert(url, result):
    """
    Sends a phishing alert message to Telegram.
    """
    try:
        message = f"🚨 Phishing Alert! 🚨\nURL: {url}\nResult: {result}"
        api_url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
        data = {"chat_id": TELEGRAM_CHAT_ID, "text": message}
        response = requests.post(api_url, data=data)
        response.raise_for_status()
    except Exception as e:
        print("Error sending Telegram alert:", e)

# MySQL Database connection and logging
def log_detection(url, result):
    """
    Logs the phishing detection result into the MySQL database.
    """
    try:
        conn = mysql.connector.connect(
            host='localhost', user='root', password='', database='phishing_detection'
        )
        cursor = conn.cursor()
        cursor.execute("INSERT INTO logs (url, result) VALUES (%s, %s)", (url, result))
        conn.commit()
        conn.close()
    except Exception as e:
        print("Error logging detection:", e)

def preprocess_url(url):
    """
    Preprocesses the URL by removing http(s) and www.
    """
    url = re.sub(r'http[s]?://', '', url)
    url = re.sub(r'www\.', '', url)
    return url

# Serve the main HTML file
@app.route('/')
def serve_index():
    return send_from_directory(app.static_folder, 'index.html')

@app.route('/check-phishing', methods=['POST'])
def check_phishing():
    """
    Endpoint to check if a URL is phishing or safe.
    """
    try:
        data = request.get_json()
        print("Received data:", data)
        url = data.get('url', '')

        if not url:
            return jsonify({'message': 'No URL provided'}), 400

        preprocessed_url = preprocess_url(url)
        print("Preprocessed URL:", preprocessed_url)
        features = vectorizer.transform([preprocessed_url])
        print("Features:", features)
        prediction = model.predict(features)
        print("Prediction:", prediction)

        result = 'Phishing Detected!' if prediction[0] == 1 else 'This is a Safe URL.'
        
        # Log the detection
        log_detection(url, result)

        # Send Telegram alert if phishing is detected
        if prediction[0] == 1:
            send_telegram_alert(url, result)

        return jsonify({'message': result})

    except Exception as e:
        print("Error in /check-phishing:", e)
        return jsonify({'message': 'Error detecting phishing.'}), 500

@app.route('/get-history', methods=['GET'])
def get_history():
    """
    Fetches the last 10 detection records from the database.
    """
    try:
        conn = mysql.connector.connect(
            host='localhost', user='root', password='', database='phishing_detection'
        )
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT url, result, timestamp FROM logs ORDER BY timestamp DESC LIMIT 10")
        history = cursor.fetchall()
        conn.close()
        return jsonify(history)
    except Exception as e:
        print("Error fetching history:", e)
        return jsonify({'message': 'Error fetching history'}), 500

if __name__ == '__main__':
    app.run(debug=True) 