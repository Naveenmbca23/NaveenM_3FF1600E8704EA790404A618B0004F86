document.getElementById('phishing-form').addEventListener('submit', function (e) {
    e.preventDefault();

    const url = document.getElementById('url-input').value;
    fetch('/check-phishing', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ url: url })
    })
    .then(response => response.json())
    .then(data => {
        document.getElementById('result').innerHTML = data.message;
    })
    .catch(error => {
        document.getElementById('result').innerHTML = 'Error detecting phishing.';
    });
});
