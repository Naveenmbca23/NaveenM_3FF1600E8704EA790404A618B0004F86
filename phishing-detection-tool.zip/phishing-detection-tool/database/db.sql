CREATE DATABASE IF NOT EXISTS phishing_detection;

USE phishing_detection;

CREATE TABLE IF NOT EXISTS logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    url VARCHAR(255),
    result VARCHAR(50),
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
INSERT INTO logs (url, result) VALUES 
('http://example.com', 'Safe'),
('http://phishingsite.com', 'Phishing Detected!');
